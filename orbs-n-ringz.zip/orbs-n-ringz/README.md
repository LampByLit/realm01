# Orbs N Ringz

A Pen created on CodePen.

Original URL: [https://codepen.io/atzedent/pen/wBKERBE](https://codepen.io/atzedent/pen/wBKERBE).

Fun little shader doodle, heavily influenced by KomaTebe's [tw_OrbsNRingz](https://openprocessing.org/sketch/1603773). I just wanted to recreate it with only a fragment shader so I could play around with it.