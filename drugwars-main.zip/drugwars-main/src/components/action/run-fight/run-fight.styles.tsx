import styled from "styled-components";

export const RunFightContainer = styled.form`
  display: grid;
  row-gap: 5px;
`;
