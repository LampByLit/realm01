import styled from "styled-components";

export const CopsChaseContainer = styled.div`
  height: 100%;
  width: 100%;
  text-align: center;
  display: grid;
  align-content: center;
`;
